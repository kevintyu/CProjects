#define  ENV_WIDTH       800
#define  ENV_HEIGHT      600

typedef struct {
  
} Obstacle;

// These are the external functions being used by the test program
extern void initializeWindow() ;
extern void closeWindow();
extern void displayEnvironment(Environment *);
